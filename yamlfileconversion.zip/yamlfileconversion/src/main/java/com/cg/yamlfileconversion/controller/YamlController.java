package com.cg.yamlfileconversion.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.yamlfileconversion.dto.YamlDto;
import com.cg.yamlfileconversion.service.YamlService;

    @RestController
	public class YamlController {

		@Autowired
		YamlService service;

		 
		 @RequestMapping(value= "/yamlApplication", method= RequestMethod.GET)
		    public String  getdetails(@RequestBody YamlDto dto) throws IOException {
				return service.getdetails(dto);
		    }
		 
	}



