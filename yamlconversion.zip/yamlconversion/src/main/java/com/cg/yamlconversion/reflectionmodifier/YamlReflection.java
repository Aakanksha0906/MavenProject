package com.cg.yamlconversion.reflectionmodifier;

import java.util.Set;

import org.reflections.Reflections;

public class YamlReflection {
	
	public Object getclassdetails() {
		Reflections reflections = new Reflections("com.cg.yamlconversion.xml");
		Set<Class<? extends Object>> allClasses =  reflections.getSubTypesOf(Object.class);
		for (Class<? extends Object> obj : allClasses){
			try {
				Object your = obj.newInstance();
				System.out.println(""  +your);
		        }
			catch (Exception e) { 
				e.printStackTrace();
				}
			}
		return allClasses; }
	}




