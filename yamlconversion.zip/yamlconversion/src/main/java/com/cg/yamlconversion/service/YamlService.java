package com.cg.yamlconversion.service;

import java.io.IOException;

import com.cg.yamlconversion.dto.YamlDto;

public interface YamlService {

	int aakanksha=0;

	public String getdetails(YamlDto dto) throws IOException;
	

}
