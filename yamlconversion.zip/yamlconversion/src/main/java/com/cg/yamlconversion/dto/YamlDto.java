package com.cg.yamlconversion.dto;

import lombok.Data;

@Data
public class YamlDto {
	private String version;
	private String host;
	private String basePath;
	private String xmlPath;
	private String yamlPath;
	private String title;
	
	
	public YamlDto() {
		super();
	}
	public YamlDto(String version, String host, String basePath, String xmlPath, String yamlPath, String title) {
		super();
		this.version = version;
		this.host = host;
		this.basePath = basePath;
		this.xmlPath = xmlPath;
		this.yamlPath = yamlPath;
		this.title = title;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getBasePath() {
		return basePath;
	}
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}
	public String getXmlPath() {
		return xmlPath;
	}
	public void setXmlPath(String xmlPath) {
		this.xmlPath = xmlPath;
	}
	public String getYamlPath() {
		return yamlPath;
	}
	public void setYamlPath(String yamlPath) {
		this.yamlPath = yamlPath;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

}






