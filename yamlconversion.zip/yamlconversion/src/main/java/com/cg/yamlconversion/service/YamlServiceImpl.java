package com.cg.yamlconversion.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Service;

import com.cg.yamlconversion.dto.YamlDto;

@Service
public class YamlServiceImpl implements YamlService {

	@Override
	public String getdetails(YamlDto dto) throws IOException {
          
		FileWriter fileW = new FileWriter("ABC.txt"); 
	      
        // Initializing a BufferedWriter 
    	BufferedWriter buffW = new BufferedWriter(fileW);	
    	
		buffW.write("swagger:2.0" );
		buffW.newLine();
		buffW.write("info:");
		buffW.newLine();
		buffW.write("\t description:Regarding the pets details");
		buffW.newLine();
		buffW.write("\t Version:"+dto.getVersion());
		buffW.newLine();
		buffW.write("\t Title:"  +dto.getTitle());
		buffW.newLine();
		buffW.write("Host:"   +dto.getHost());
		buffW.newLine();
		buffW.write("BasePath" +dto.getBasePath());
		buffW.newLine();
		buffW.write("schemes:\n -https");
		buffW.newLine();
		buffW.close();
		
		
		return "written successfully" ; 
	}

}
