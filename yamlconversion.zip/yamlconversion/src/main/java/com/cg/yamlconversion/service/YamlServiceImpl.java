package com.cg.yamlconversion.service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.springframework.stereotype.Service;

import com.cg.yamlconversion.dto.YamlDto;
import com.cg.yamlconversion.reflectionmodifier.YamlReflection;

@Service
public class YamlServiceImpl implements YamlService {

	int aakanksha = 0;

	@Override
	public String getdetails(YamlDto dto) throws IOException {

		FileWriter fileW = new FileWriter("ABC.yml");
		YamlReflection ref = new YamlReflection();
		// Initializing a BufferedWriter
		BufferedWriter buffW = new BufferedWriter(fileW);

		buffW.write("swagger:2.0");
		buffW.newLine();
		buffW.write("info:");
		buffW.newLine();
		buffW.write("\t description:Regarding the pets details");
		buffW.newLine();
		buffW.write("\t Version:" + dto.getVersion());
		buffW.newLine();
		buffW.write("\t Title:" + dto.getTitle());
		buffW.newLine();
		buffW.write("Host:" + dto.getHost());
		buffW.newLine();
		buffW.write("BasePath" + dto.getBasePath());
		buffW.newLine();
		buffW.write("schemes:\n -https");
		buffW.newLine();
		buffW.newLine();
		Set<Class<? extends Object>> allClasses = getclassdetails();
		buffW.write("Cat Parameters:");
		for (Class<? extends Object> obj : allClasses) {
			for (Field field : obj.getDeclaredFields()) {
				buffW.write(field.getName());
				buffW.write(",");
			}
			// buffW.write(obj.getClass().getFields().toString());
		}
		buffW.close();
		return "written successfully";

	}

	public YamlReflection getCatParameters(YamlReflection ref) throws IOException {
		ref.getClass().getDeclaredFields();
		System.out.println("Fields" + ref.getClass().getDeclaredFields());
		return ref;

	}

	public Set<Class<? extends Object>> getclassdetails() {
		Reflections reflections = new Reflections("com.cg.yamlconversion.service", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Object.class);
	}
}
