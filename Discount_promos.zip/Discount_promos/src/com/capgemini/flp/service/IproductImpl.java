package com.capgemini.flp.service;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.flp.dao.Iproductdao;

@Service
@Transactional
public class IproductImpl implements Iproductdao{
	
		@Autowired
		Iproductdao productdao;

		
		@Override
		public double details() {
			// TODO Auto-generated method stub
			return productdao.details();
		

	}
}

	
	
	
	