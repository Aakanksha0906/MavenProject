package com.capgemini.flp.service;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.beans.Merchant;
import com.capgemini.flp.dao.Iproductdao;

@Service
@Transactional
public class IproductImpl implements Iproduct{
	
		@Autowired
		Iproductdao productdao;

		
		@Override
		public Merchant details(String promo) {
			// TODO Auto-generated method stub
			return productdao.details(promo);
		

	}
		@Override
		public boolean discountUpdation(int userid) {
			// TODO Auto-generated method stub
			return productdao.discountUpdation(userid);
		}
}

	
	
	
	