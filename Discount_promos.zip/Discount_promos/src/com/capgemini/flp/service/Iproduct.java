package com.capgemini.flp.service;
public interface Iproduct   {
	//public double details(Merchant b);

	public double details();
	
}
