package com.capgemini.flp.service;

import com.capgemini.flp.beans.Merchant;

public interface Iproduct   {
	//public double details(Merchant b);

	public Merchant details(String promo);
	public boolean discountUpdation(int userid);
}
