package com.capgemini.flp.springbootcontroller;

/*import org.springframework.beans.factory.annotation.Autowired();*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.beans.Merchant;
import com.capgemini.flp.service.Iproduct;



@Configuration
@Controller
public class Product {
	
@Autowired
Iproduct productservice;


@RequestMapping(value="/")
public String getIndexPage() {
	
	return "index";
}

@RequestMapping(value="/promo")
public String dataDisplay() {
	return "promopage";
}	

	@RequestMapping(value="/prod")
	public ModelAndView details(@RequestParam(value="promo")String promo) {
		
		Merchant m=productservice.details(promo);
		
		return new ModelAndView("Discountpromo", "m", m);
	}
	
	@RequestMapping(value="/apply")
	public ModelAndView discount(@RequestParam(value="userid")Integer userid)
	{
          String result;
		boolean b=productservice.discountUpdation(userid);
		if(b)
		{
			result="Your Discount amount got reduced  Successfully from the actual amount";
		}
		else
		{
			result="Unsuccessfull";
		}
          return new ModelAndView("Success","result",result);
	}
	
	
}
	


