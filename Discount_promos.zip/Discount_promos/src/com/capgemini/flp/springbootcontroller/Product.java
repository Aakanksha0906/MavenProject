package com.capgemini.flp.springbootcontroller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.service.Iproduct;


@Controller
public class Product {
	
@Autowired
Iproduct productser;
/*protected void doPost(HttpServletRequest req,HttpServletResponse res)
	{

	 Iproduct product = null;

    double e ;
	 String a=req.getParameter("promo");
	  Merchant b =new Merchant();
     b.setProduct_Promo(a);
     e=product.details(b);
	}
}*/

@RequestMapping(value="/")
public String getIndexPage() {
	
	return "index";
}
     
	@RequestMapping(value="/prod",method=RequestMethod.GET)
	public ModelAndView details() {
		double productData=productser.details();
		//Merchant productData =new Merchant();
		return new ModelAndView("Discountpromo", "data", productData);
	}
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public ModelAndView dataDisplay(@RequestParam("un") String cname) {
		
		return new ModelAndView("login", "ename", cname);
	
	
}
}
	


