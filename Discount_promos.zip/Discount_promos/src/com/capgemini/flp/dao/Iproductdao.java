package com.capgemini.flp.dao;

import org.springframework.context.annotation.Configuration;

@Configuration
public interface Iproductdao {

	public double details();
	
}
