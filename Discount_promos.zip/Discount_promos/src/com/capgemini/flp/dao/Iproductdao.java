package com.capgemini.flp.dao;

import org.springframework.context.annotation.Configuration;

import com.capgemini.flp.beans.Merchant;

@Configuration
public interface Iproductdao {

	public Merchant details(String promo);
	public boolean discountUpdation(int userid);

}
