package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.beans.Merchant;

@Configuration
@Repository
@Transactional
public class productdaoImpl implements Iproductdao{

	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public double details() {
		Merchant c=new Merchant();
		double d;
		String rs="select temp from merchant_product temp where product_Id= :id";
		TypedQuery<Merchant> query = em.createQuery(rs, Merchant.class);
		query.setParameter("id",1);//get the product id  
		
		
		
		c = query.getSingleResult();
		
		//#After Discount Price #
		if(c.getProduct_Promo().equalsIgnoreCase("Hi"))//get the promo code
		{

		 d= c.getProduct_Price()-((5*c.getProduct_Price())/100);
		}
		else
		{
		d = 0;
		}
		c.setProduct_Discount(d);
		em.persist(c);
		

		
		return c.getProduct_Price()-d;
		//return null;
}
}

