package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;



/*import org.springframework.beans.factory.annotation.Autowired;*/
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;





import com.capgemini.flp.beans.Merchant;

@Configuration
@Repository
public class productdaoImpl implements Iproductdao{


	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public Merchant details(String promo) {
		Merchant merchant=new Merchant();
		double d;
		String rs1="select m from Merchant m where m.product_Id=?1";
		TypedQuery<Merchant> query = em.createQuery(rs1, Merchant.class);
		query.setParameter(1,2);//get the product id  //1 will be replaced by the present session user
		merchant = query.getSingleResult();
		System.out.println(merchant);
		
		//#After Discount Price #
		if(merchant.getProduct_Promo().equalsIgnoreCase(promo))//get the promo code from the user
		{

		 d=((merchant.getProduct_Discount()*merchant.getProduct_Price())/100);
		 
		}
		else
		{
		d = 0;
		}
		
		merchant.setProduct_Discount(d);
		em.persist(merchant);
	
		return merchant;
	
}


	@Override
	public boolean discountUpdation(int userid)
	{
		Merchant merchant=new Merchant();
		
		String rs1="select m from Merchant m where m.product_Id=?1";
		TypedQuery<Merchant> query = em.createQuery(rs1, Merchant.class);
		query.setParameter(1,2);//get the product id  //1 will be replaced by the present session user
		merchant = query.getSingleResult();
		if(merchant.getProduct_Id()==userid)
		{
			double d;
		/*	 d=((merchant.getProduct_Discount()*merchant.getProduct_Price())/100);*/
			 merchant.setProduct_Price(merchant.getProduct_Price()-merchant.getProduct_Discount());
			
			return true;
		}
		else
		{
			merchant.setProduct_Price(merchant.getProduct_Price());
			return false;
		}
		
	}
}

